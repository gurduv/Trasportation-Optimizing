$("#reload").click(function () {
    location.reload(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
});